# Standalone Installation

This is a standalone distribution of the Ahotu Event Search Raycast extension.

## Quick Install

1. Extract this archive
2. Open Terminal and navigate to this folder
3. Run the installer:
   ```bash
   ./install.sh
   ```

## Manual Installation

If the installer doesn't work:

```bash
# Install pnpm if needed
npm install -g pnpm

# Install dependencies
pnpm install

# Import to Raycast
pnpm dev
```

## Configuration

After installation:

1. Open Raycast (⌘ + Space)
2. Search for "Search Events"
3. Press ⌘ + , to open preferences
4. Configure:
   - **API Base URL**: `https://core.ahotu.com`
   - **API Token**: Get from your team lead

## Usage

Search for events with powerful filters:

- `marathon country:USA @2024`
- `triathlon month:jun reg:California`
- `running -virtual @client`

See README.md for full documentation.

## Troubleshooting

**"pnpm: command not found"**
```bash
npm install -g pnpm
```

**"API request failed: 401"**
- Check your API token in Raycast preferences

**Need help?**
- Check README.md
- Ask in your team Slack channel

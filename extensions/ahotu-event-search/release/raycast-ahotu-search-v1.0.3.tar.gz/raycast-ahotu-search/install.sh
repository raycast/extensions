#!/bin/bash

# Standalone installer for Ahotu Event Search Raycast Extension
set -e

echo "🚀 Installing Ahotu Event Search for Raycast"
echo "============================================"
echo ""

# Check prerequisites
if ! command -v raycast &> /dev/null; then
    echo "❌ Raycast is not installed."
    echo "   Download from: https://raycast.com/"
    exit 1
fi
echo "✅ Raycast found"

REQUIRED_PNPM_VERSION="10.29.3"

if ! command -v pnpm &> /dev/null; then
    echo "⚠️  pnpm is not installed. Installing pnpm@${REQUIRED_PNPM_VERSION}..."
    npm install -g pnpm@${REQUIRED_PNPM_VERSION}
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install pnpm"
        echo "   Please install manually: npm install -g pnpm@${REQUIRED_PNPM_VERSION}"
        exit 1
    fi
else
    PNPM_VERSION=$(pnpm --version)
    PNPM_MAJOR=$(echo $PNPM_VERSION | cut -d'.' -f1)
    if [ "$PNPM_MAJOR" -lt 9 ]; then
        echo "⚠️  pnpm version too old: $PNPM_VERSION (need 9.0.0+)"
        echo "   Upgrading to pnpm@${REQUIRED_PNPM_VERSION}..."
        npm install -g pnpm@${REQUIRED_PNPM_VERSION}
    fi
fi
echo "✅ pnpm $(pnpm --version)"

# Check Node.js version
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed."
    echo "   Download from: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node --version)
NODE_MAJOR=$(echo $NODE_VERSION | cut -d'.' -f1 | sed 's/v//')
if [ "$NODE_MAJOR" -lt 18 ]; then
    echo "⚠️  Node.js 18+ required. Current: $NODE_VERSION"
    read -p "   Continue anyway? (y/N): " continue
    if [[ ! $continue =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi
echo "✅ Node.js $NODE_VERSION"

echo ""
echo "📦 Installing dependencies..."
pnpm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo ""
echo "🔧 Importing to Raycast..."
pnpm dev

if [ $? -ne 0 ]; then
    echo "❌ Failed to import extension"
    exit 1
fi

echo ""
echo "✅ Installation complete!"
echo ""
echo "📝 Next steps:"
echo "   1. Open Raycast (⌘ + Space)"
echo "   2. Type 'Search Events'"
echo "   3. Press ⌘ + , to configure"
echo "   4. Configure your credentials:"
echo "      - API URL: https://core.ahotu.com"
echo "      - User Email: Your Ahotu account email"
echo "      - User Token: Your authentication token"
echo "      - API Key: Your API key"
echo ""
echo "💡 Quick search examples:"
echo "   marathon country:USA @2024"
echo "   triathlon month:jun"
echo "   running -virtual @client"
echo ""
